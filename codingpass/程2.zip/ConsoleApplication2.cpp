﻿#include <iostream>
using namespace std;

class Course {
private:
	string name;
	int units;
	int score;
public:
	char a[5] = { 'E','D','C','B','A' };
	Course() :name(""), units(0), score(0) {}
	Course(string n, int u, int s) :name(n), units(u), score(s){}
	int getUnits() const{
		return units;
	}
	int getScore() const {
		return score;
	}
	char getGrade() const {
		if (score < 60) {
			return a[0];
		}
		else if (score < 70) {
			return a[1];
		}
		else if (score < 80) {
			return a[2];
		}
		else if (score < 90) {
			return a[3];
		}
		else if (score < 100) {
			return a[4];
		}
	}
	void print() const {
		cout << "Course: " << name << " Credit: " << units << " Score: " << score << " Grade: " << getGrade() << endl;
	}
};

class Student {
private:
	string name;
	Course* course;
	int courseCount;
	int capacity;
public:
	Student(string n) :name(n),courseCount(0),capacity(2){
		course = new Course[capacity];
	}
	void addCourse(string courseName, int courseUnits, double courseScore) {
		course[courseCount] = Course(courseName, courseUnits, courseScore);
		courseCount++;
	}
	int GetGPA() {
		
	}
	void print() const {
		cout << "Student: " << name << endl;
		for (int i = 0; i < courseCount; ++i) {
			course[i].print();
		}
		cout << "GPA: ";
	}
};
int main()
{
	Student student1("Henry");
	student1.addCourse("History", 3, 86);
	student1.addCourse("C++", 5, 70);
	student1.print();
	Student student2("Juan");
	student2.addCourse("Chem", 5, 60);
	student2.addCourse("Calc", 3, 55);
	student2.addCourse("Eng", 3, 90);
	student2.addCourse("PE", 1, 78);
	student2.print();
	return 0;
}