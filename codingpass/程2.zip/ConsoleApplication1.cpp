﻿#include <iostream>
using namespace std;

class Circle{
private:
	double radius;
	const double pi = 3.14159;
public:
	Circle(double num) :radius(num) {}
	~Circle() = default;
	void print() {
		cout << "Radius: " << radius << endl;
	}
	double getRadius() const {
		return radius;
	}
	double getPerimeter() const {
		return 2 * pi * radius;
	}
	double getArea() const {
		return pi * radius * radius;
	}
};
class Sphere : public Circle{
public:
	Sphere(double num) : Circle(num){}
	~Sphere() = default;
	double getSurface() const {
		return 2 * getRadius() * getPerimeter();
	}
	double getVolume() const {
		return (4.0 / 3.0) * getRadius() * getArea();
	}
};
int main()
{
	// Instantiation and printing perimeter and area of a circle
	Circle cir(6.0);
	cout << "Circle: " << endl;
	cir.print();
	cout << "Perimeter: ";
	cout << cir.getPerimeter() << endl;
	cout << "Area: ";
	cout << cir.getArea() << endl << endl;
	// Instantiation and printing perimeter and area of a sphere
	Sphere sph(6.0);
	cout << "Sphere: " << endl;
	sph.print();
	cout << "Surface: ";
	cout << sph.getSurface() << endl;
	cout << "Volume: ";
	cout << sph.getVolume() << endl << endl;
	return 0;
}
